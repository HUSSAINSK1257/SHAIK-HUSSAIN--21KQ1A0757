# Define train information
trains = {
    'Train1': {
        'destination': 'Hyderabad',
        'price': 175,
        'time': '2h 30m',
        'total_seats': 100,
        'available_seats': 100
    },
    'Train2': {
        'destination': 'Chennai',
        'price': 150,
        'time': '3h 45m',
        'total_seats': 80,
        'available_seats': 80
    },
    'Train3': {
        'destination': 'Hyderabad',
        'price': 275,
        'time': '2h 15m',
        'total_seats': 120,
        'available_seats': 120
    },
    'Train4': {
        'destination': 'Banglore',
        'price': 200,
        'time': '5h 00m',
        'total_seats': 60,
        'available_seats': 60
    },
    'Train5': {
        'destination': 'Chennai',
        'price': 250,
        'time': '3h 30m',
        'total_seats': 90,
        'available_seats': 90
    }
}

def display_destinations(trains):
    destinations = sorted({train['destination'] for train in trains.values()})
    print("Available Destinations:")
    for destination in destinations:
        print(destination)

def show_trains_for_destination(trains, destination):
    sorted_trains = sorted(
        [train for train in trains.items() if train[1]['destination'] == destination],
        key=lambda x: x[1]['price']
    )
    
    print(f"\nAvailable trains for {destination} (sorted by price):")
    for train_name, details in sorted_trains:
        print(f"{train_name}: Price = {details['price']}, Time = {details['time']}, Available Seats = {details['available_seats']}")

def book_ticket(trains, train_choice, seats):
    if train_choice in trains:
        selected_train = trains[train_choice]
        if selected_train['available_seats'] >= seats:
            selected_train['available_seats'] -= seats
            print("\nBooking Successful!")
            print(f"Train: {train_choice}")
            print(f"Destination: {selected_train['destination']}")
            print(f"Price per ticket: {selected_train['price']}")
            print(f"Total Price: {selected_train['price'] * seats}")
            print(f"Time: {selected_train['time']}")
            print(f"Seats booked: {seats}")
            print(f"Remaining Seats: {selected_train['available_seats']}")
        else:
            print("\nInsufficient seats available.")
    else:
        print("\nInvalid train selection. Please try again.")

def main():
    while True:
        print("\nWelcome to the Railway Ticket Reservation System!\n")
        
        # Display destinations
        display_destinations(trains)
        
        # User selects a destination
        destination = input("\nPlease enter your destination (or type 'exit' to quit): ").strip()
        
        if destination.lower() == 'exit':
            print("Exiting the system. Goodbye!")
            break
        
        # Show available trains for the selected destination
        show_trains_for_destination(trains, destination)
        
        # User selects a train
        train_choice = input("\nPlease enter the train you want to book (e.g., Train1): ").strip()
        
        # User enters number of seats
        seats = int(input(f"Enter the number of seats you want to book on {train_choice}: ").strip())
        
        # Book the ticket
        book_ticket(trains, train_choice, seats)
        
        # Ask if the user wants to book another ticket
        continue_booking = input("\nDo you want to book another ticket? (yes/no): ").strip().lower()
        if continue_booking != 'yes':
            print("Thank you for using the Railway Ticket Reservation System. Goodbye!")
            break

# Run the main function
if __name__== "__main__":
    main()
